EasyRTC Scripts Folder
======================

Any scripts needed for the development and testing of EasyRTC should find their way here.

Nothing here should be needed by end users.