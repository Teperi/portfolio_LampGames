// The EasyRTC server files are in the lib folder
module.exports = require('./lib/easyrtc_server');